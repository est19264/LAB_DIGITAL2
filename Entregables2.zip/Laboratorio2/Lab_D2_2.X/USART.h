/* 
 * File:   USART.h
 * Author: DIEGO
 *
 * Created on 26 de julio de 2021
 */

#ifndef xc_USART //definir nuevo nombre que el otro header para que no lo llame
#define	xc_USART //dos veces

#include <xc.h> // include processor files - each processor file is guarded.  

void conf_usart(void);

#endif	/* XC_HEADER_TEMPLATE_H */
