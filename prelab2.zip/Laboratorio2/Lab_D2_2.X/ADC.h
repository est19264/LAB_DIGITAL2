/* 
 * File:   ADC.h
 * Author: diego
 *
 * Created on 18 de julio de 2021
 */

#ifndef ADC_H
#define	ADC_H

#include <xc.h> 
#include <stdint.h>

uint8_t configADC(uint8_t ch);

#endif	/* ADC_H */