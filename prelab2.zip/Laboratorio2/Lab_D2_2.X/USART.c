#include <stdint.h>
#include <xc.h>
#include <stdio.h> 
#include <pic16f887.h>
#include "USART.h"
#define _XTAL_FREQ 4000000 

//
//void _baudios(void){
//    SPBRG = 12; //9600 baudios para 8MHZ
//}
////Configuracion dada en el datasheet
//void config_tx(void){
//    TXSTAbits.CSRC = 0;//Clock terminal
//    TXSTAbits.TX9 = 0;//8 bits de transmicion 
//    TXSTAbits.TXEN = 1;//Transmicion habilitada
//    TXSTAbits.SYNC = 0;//modo asincrono
//    TXSTAbits.BRGH = 0;//low speed
//    TXSTAbits.TRMT = 0;//Tsr full
//    TXSTAbits.TX9D = 0;
//}
////Configuracion dada en el datasheet
//void config_rc(void){
//    RCSTAbits.SPEN = 1;//Se habilita el puerto serial 
//    RCSTAbits.RX9 = 0;
//    RCSTAbits.SREN = 0;
//    RCSTAbits.CREN = 1;//Recibir habilitadp 
//    RCREG = 0;  
//}
//void Write_USART(uint8_t a){
//    while(!TRMT);
//    TXREG=a;
//}
//void Write_USART_String(char *a){
//    uint8_t i;
//    for(i=0;a[i]!='\0';i++){
//        Write_USART(a[i]);
//    }
//}
//uint8_t Read_USART(){
//  while(!RCIF);
//  return RCREG;
//}

uint8_t contador = 0;

// Configuraciones TX y RX
    
void config_tx_rx (void){
    TXSTAbits.SYNC = 0;                     // Apaga SYNC
    TXSTAbits.BRGH = 1;                     // Prende BRGH
    BAUDCTLbits.BRG16 = 1;                  // Prende BRG16
    
    SPBRG = 208;
    SPBRGH = 0;
    
    RCSTAbits.SPEN = 1;                     // Prende SPEN
    RCSTAbits.RX9 = 0;                      // Apaga RX9
    RCSTAbits.CREN = 1;                     // Prende CREN
    
    TXSTAbits.TXEN = 1;                     // Prende TXTEN
    
    PIR1bits.RCIF = 0;                      // Bandera rx
    PIR1bits.TXIF = 0;                      // bandera tx
}

void putch(char data){        
    while(TXIF == 0);
    TXREG = data;                           // Valor de la cadena de printf
    return;
}

void inter_uart (void){
// Interrupción para la implementción de UART
    if (RCIF == 1){
    // Configuración para las opciones 
    if (RCREG == '+'){                      // Primera opción, sumar al contador
        __delay_ms(500);
        contador = contador + 1;

    }
    if (RCREG == '-'){                      // Segunda opción, restar al contador
        __delay_ms(500);
        contador = contador - 1;
    }

    else{                                   // Ignorar por si se ingresa una opción no válida
        NULL;                 
    }
    return;
}
}